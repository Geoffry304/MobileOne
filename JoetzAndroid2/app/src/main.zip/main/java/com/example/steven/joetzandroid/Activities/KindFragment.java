package com.example.steven.joetzandroid.Activities;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.steven.joetzandroid.Domain.Kind;
import com.example.steven.joetzandroid.Domain.Ouder;
import com.example.steven.joetzandroid.R;
import com.example.steven.joetzandroid.firebase.FirebaseAuth;
import com.example.steven.joetzandroid.firebase.FirebaseProfile;

/**
 * Created by thomas on 15/12/14.
 */
public class KindFragment extends Fragment {
    private static final String TAG = "kindFragment";
    private Kind kind;
    private EditText txtVoornaam;
    private EditText txtNaam;
    private EditText txtNr;
    private EditText txtPostcode;
    private EditText txtStraat;
    private EditText txtGemeente;
    private EditText txtRijksregisternr;
    private Button btnOpslaan;
    private FirebaseProfile frbProfile;
    private FirebaseAuth auth = new FirebaseAuth();

    //dummiedata


    public void setKind(Kind kind){
        this.kind = kind;
    }

    public Kind getKind(){return this.kind;}

    public KindFragment() {

        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, kind.toString());

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        frbProfile = new FirebaseProfile(this.auth);
        View view = inflater.inflate(R.layout.fragment_kind, container, false);
        loadElementen(view);
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    private View.OnClickListener onKlikOpslaan = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            listenersElementen();
            frbProfile.updateKind(kind);
            frbProfile.updateKindAdres(kind);

        }
    };


    public void listenersElementen(){
        txtNaam.addTextChangedListener(new TextWatcher(){
            public void afterTextChanged(Editable s) {
                kind.setLastName(txtNaam.getText().toString());
            }
            public void beforeTextChanged(CharSequence s, int start, int count, int after){}
            public void onTextChanged(CharSequence s, int start, int before, int count){}
        });
        txtVoornaam.addTextChangedListener(new TextWatcher(){
            public void afterTextChanged(Editable s) {
                kind.setFistName(txtVoornaam.getText().toString());
            }
            public void beforeTextChanged(CharSequence s, int start, int count, int after){}
            public void onTextChanged(CharSequence s, int start, int before, int count){}
        });
        txtGemeente.addTextChangedListener(new TextWatcher(){
            public void afterTextChanged(Editable s) {
                kind.getAdres().setGemeente(txtGemeente.getText().toString());
            }
            public void beforeTextChanged(CharSequence s, int start, int count, int after){}
            public void onTextChanged(CharSequence s, int start, int before, int count){}
        });
        txtRijksregisternr.addTextChangedListener(new TextWatcher(){
            public void afterTextChanged(Editable s) {
                kind.setRijksRegisternummer(txtRijksregisternr.getText().toString());
            }
            public void beforeTextChanged(CharSequence s, int start, int count, int after){}
            public void onTextChanged(CharSequence s, int start, int before, int count){}
        });
        txtStraat.addTextChangedListener(new TextWatcher(){
            public void afterTextChanged(Editable s) {
                kind.getAdres().setStraat(txtStraat.getText().toString());
            }
            public void beforeTextChanged(CharSequence s, int start, int count, int after){}
            public void onTextChanged(CharSequence s, int start, int before, int count){}
        });
        txtPostcode.addTextChangedListener(new TextWatcher(){
            public void afterTextChanged(Editable s) {
                kind.getAdres().setPostcode(Integer.parseInt(txtPostcode.getText().toString()));
            }
            public void beforeTextChanged(CharSequence s, int start, int count, int after){}
            public void onTextChanged(CharSequence s, int start, int before, int count){}
        });
        txtNr.addTextChangedListener(new TextWatcher(){
            public void afterTextChanged(Editable s) {
                kind.getAdres().setNummer(Integer.parseInt(txtNr.getText().toString()));
            }
            public void beforeTextChanged(CharSequence s, int start, int count, int after){}
            public void onTextChanged(CharSequence s, int start, int before, int count){}
        });

    }

    public void loadElementen(View view){
        txtNaam = (EditText)view.findViewById(R.id.profileKindEditTextNaam);
        txtVoornaam = (EditText)view.findViewById(R.id.profileKindEditTextVoornaam);
        txtNr = (EditText)view.findViewById(R.id.profileKindEditTextNr);
        txtPostcode = (EditText)view.findViewById(R.id.profileKindEditTextPostcode);
        txtStraat = (EditText)view.findViewById(R.id.profileKindEditTextStraat);
        txtGemeente = (EditText)view.findViewById(R.id.profileKindEditTextGemeente);
        txtRijksregisternr = (EditText)view.findViewById(R.id.profileKindEditTextRijksregisternr);
        txtNaam.setText(kind.getLastName());
        txtVoornaam.setText(kind.getFistName());
        txtNr.setText(kind.getAdres().getNummer());
        txtStraat.setText(kind.getAdres().getStraat());
        txtGemeente.setText(kind.getAdres().getGemeente());
        txtPostcode.setText(kind.getAdres().getPostcode());
        txtRijksregisternr.setText(kind.getRijksRegisternummer());
        btnOpslaan = (Button)view.findViewById(R.id.profileKindButtonOpslaan);

    }

}
