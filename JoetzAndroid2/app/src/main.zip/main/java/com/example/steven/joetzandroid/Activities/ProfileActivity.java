package com.example.steven.joetzandroid.Activities;

import android.app.ActionBar;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.widget.Toast;

import com.example.steven.joetzandroid.Domain.Kind;
import com.example.steven.joetzandroid.Domain.Ouder;
import com.example.steven.joetzandroid.R;
import com.example.steven.joetzandroid.firebase.FirebaseProfile;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by thomas on 13/12/14.
 */
public class ProfileActivity extends FragmentActivity implements ActionBar.TabListener{

    private Map<String,ProfileFragment> fragmentMap;
    private Ouder ouder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_profile);
        fragmentMap = new HashMap<String,ProfileFragment>();
        createTabbar();
        FirebaseProfile profile = new FirebaseProfile();
        ouder = profile.getOuder();

    }

    private ActionBar actionbar;
    public void createTabbar() {
        actionbar = this.getActionBar();
        actionbar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
        //maak in values bij arrays een array aan met de nodige dingen (algemeen, contact, kinderen, partner)
        String[] items = getResources().getStringArray(R.array.tab_bar_items);

        for (int i = 0; i < items.length; i++) {
            actionbar.addTab(actionbar.newTab().setText(items[i]).setTabListener(this));
            //hier moet je de hasmap opvullen, maak misschien een Array van ProfileFragmenten in dezelfde volgorde als de strings, en vul op.

        }
    }

    @Override
    public void onTabSelected(ActionBar.Tab tab, android.app.FragmentTransaction fragmentTransaction) {

        if(fragmentMap.containsKey(tab.getText())){
            ProfileFragment f = fragmentMap.get(tab.getText());
            if (this.ouder != null) {
                f.setOuder(this.ouder); //zorg dat die niet leeg is
                FragmentManager fMan = getSupportFragmentManager();
                fMan.beginTransaction().addToBackStack(null).replace(R.id.frame_profile, f).commit();
            }
            else{
                Context context = getApplicationContext();
                CharSequence text = "U bent niet aangemeld!";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        }
    }

    @Override
    public void onTabUnselected(ActionBar.Tab tab, android.app.FragmentTransaction fragmentTransaction) {

    }

    @Override
    public void onTabReselected(ActionBar.Tab tab, android.app.FragmentTransaction fragmentTransaction) {

    }


}
