package com.example.steven.joetzandroid.Domain;

/**
 * Created by Steven on 24/10/14.
 */
public class Monitor extends User {
}
