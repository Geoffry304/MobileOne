package com.example.steven.joetzandroid.Adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.steven.joetzandroid.Domain.Kind;
import com.example.steven.joetzandroid.Domain.NavDrawerItem;
import com.example.steven.joetzandroid.R;

import java.util.ArrayList;

/**
 * Created by thomas on 15/12/14.
 */
public class KindAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<Kind> kinderen;

    public KindAdapter(Context context, ArrayList<Kind> kinderen) {
        this.context = context;
        this.kinderen = kinderen;
    }

    @Override
    public int getCount() {
        return kinderen.size();
    }

    @Override
    public Object getItem(int i) {
        return kinderen.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if(view == null)
        {
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.drawer_list_item,null);
        }

        TextView txtTitle = (TextView)view.findViewById(R.id.list_item_textview);


        txtTitle.setText(kinderen.get(i).getFistName() + " " + kinderen.get(i).getLastName());

        return view;
    }


}
